<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

// Include database connection
require_once '../config/database.php';

// Start the session
session_start();

// Get JSON input
$data = json_decode(file_get_contents("php://input"), true);

if ($data) {
    $email = $data['email'] ?? '';
    $password = $data['password'] ?? '';
    $errors = ['email' => '', 'password' => ''];

    // Email validation
    if (empty($email)) {
        $errors['email'] = 'ایمیل الزامی است.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = 'فرمت ایمیل معتبر نیست.';
    }

    // Password validation
    if (empty($password)) {
        $errors['password'] = 'رمز عبور الزامی است.';
    }

    // If no errors, check credentials
    if (!array_filter($errors)) {
        $query = "SELECT * FROM users WHERE email = ?";
        $stmt = $conn->prepare($query);
        if (!$stmt) {
            echo json_encode(["error" => "Database query preparation failed."]);
            exit;
        }
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();
            if (password_verify($password, $user['password'])) {
                // Store user data in the session
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['email'] = $user['email'];

                echo json_encode(["message" => "ورود با موفقیت انجام شد!", "user" => $user]);
            } else {
                echo json_encode(["error" => "رمز عبور اشتباه است."]);
            }
        } else {
            echo json_encode(["error" => "کاربری با این ایمیل یافت نشد."]);
        }
    } else {
        echo json_encode(["errors" => $errors]);
    }
}
?>