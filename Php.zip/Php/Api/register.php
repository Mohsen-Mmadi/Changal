<?php
// Include database connection
require_once '../config/database.php';

// Initialize variables
$username = $email = $password = '';
$errors = ['username' => '', 'email' => '', 'password' => ''];

// Get JSON input
$data = json_decode(file_get_contents("php://input"), true);

if ($data) {
    // Username validation
    if (empty($data['username'])) {
        $errors['username'] = 'نام کاربری الزامی است.';
    } else {
        $username = $data['username'];
        if (!preg_match('/^[a-zA-Z0-9_]{3,50}$/', $username)) {
            $errors['username'] = 'نام کاربری باید بین ۳ تا ۵۰ کاراکتر و فقط شامل حروف، اعداد و زیرخط باشد.';
        }
    }

    // Email validation
    if (empty($data['email'])) {
        $errors['email'] = 'ایمیل الزامی است.';
    } else {
        $email = $data['email'];
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors['email'] = 'فرمت ایمیل معتبر نیست.';
        }
    }

    // Password validation
    if (empty($data['password'])) {
        $errors['password'] = 'رمز عبور الزامی است.';
    } else {
        $password = $data['password'];
        if (strlen($password) < 8) {
            $errors['password'] = 'رمز عبور باید حداقل ۸ کاراکتر باشد.';
        }
    }

    // If no errors, insert into database
    if (!array_filter($errors)) {
        $hashedPassword = password_hash($password, PASSWORD_BCRYPT);

        $query = "INSERT INTO users (username, email, password) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($query);

        if (!$stmt) {
            echo json_encode(["error" => "Database query preparation failed."]);
            exit;
        }

        $stmt->bind_param("sss", $username, $email, $hashedPassword);

        if ($stmt->execute()) {
            echo json_encode(["message" => "ثبت‌نام با موفقیت انجام شد!"]);
        } else {
            echo json_encode(["error" => "ایمیل یا نام کاربری قبلاً ثبت شده است."]);
        }
    } else {
        echo json_encode(["errors" => $errors]);
    }
}
?>