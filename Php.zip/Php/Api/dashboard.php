<?php

session_start();


if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="UTF-8">
    <title>داشبورد</title>
</head>
<body>
    <h1>خوش آمدید، <?php echo htmlspecialchars($_SESSION['username']); ?>!</h1>
    <p>ایمیل شما: <?php echo htmlspecialchars($_SESSION['email']); ?></p>
    <a href="logout.php">خروج</a>
</body>
</html>