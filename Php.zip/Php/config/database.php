<?php
  
  $host = 'localhost'; 
  $db_name = 'Changl';
  $username = 'Yazdan';
  $password = '8dYlCdQdweh]';

  $conn =mysqli_connect ($host, $username, $password, $db_name);

  if (!$conn){
    echo'Connection error ' . mysqli_connect_error();
}
  

?>